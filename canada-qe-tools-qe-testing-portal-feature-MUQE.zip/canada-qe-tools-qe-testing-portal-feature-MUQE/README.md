# testing-portal-web-app-project

Sample Node.JS Express project for TestME web application

## How to start the application
1. npm install
2. npm start
3. Open the browser and go to http://localhost:8080/

## How to push directly to PCF
cf push qualityservices-testing-web-portal -b nodejs_buildpack
