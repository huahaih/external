module.exports = {
  env: {
    browser: true,
    es2021: true,
    node: true,
  },
  extends: [
    'manulife/lib/react',
  ],
  parserOptions: {
    ecmaVersion: 12,
    sourceType: 'module',
  },
  rules: {
    indent: ['error', 2],
    'no-var': 'off',
    'no-undef': 'off',
    'no-console': 'off',
    'no-plusplus': 'off',
    'linebreak-style': 'off',
    'import/extensions': 'off',
    'import/no-duplicates': 'off',
    'import/no-unresolved': 'off',
    'import/no-named-as-default-member': 'off',
  },
};
