/* eslint-disable array-callback-return */
const sinon = require('sinon');
const expect = require('chai').expect;
const Comment = require('../src/models/commentModel');

describe('Mock test Mongoose Response', () => {
  describe('Get all comments', () => {
    // Test will pass if we get all comments
    it('should return all comments', (done) => {
      const Mock = sinon.mock(Comment);
      const expectedResult = { status: true, comments: [] };
      Mock.expects('find').yields(null, expectedResult);
      Comment.find((err, result) => {
        Mock.verify();
        Mock.restore();
        expect(result.status).to.be.true;
        done();
      });
    });

    // Test will pass if we fail to get comments
    it('should return error', (done) => {
      const Mock = sinon.mock(Comment);
      const expectedResult = { status: false, error: 'Something went wrong' };
      Mock.expects('find').yields(expectedResult, null);
      Comment.find((err, result) => {
        Mock.verify();
        Mock.restore();
        expect(err.status).to.not.be.true;
        done();
      });
    });
  });

  // Test will pass if a new comment is added
  describe('Add a new comment', () => {
    it('should add a new comment', (done) => {
      const Mock = sinon.mock(new Comment({ name: 'Tony', email: 'tony@manulife.ca', subject: 'To J Snow', comments: 'I know nothing either' }));
      const comment = Mock.object;
      const expectedResult = { status: true };
      Mock.expects('save').yields(null, expectedResult);
      comment.save((err, result) => {
        Mock.verify();
        Mock.restore();
        expect(result.status).to.be.true;
        done();
      });
    });

    // Test will pass if a new doctor is not added
    it('should return error, if a comment is not added', (done) => {
      const Mock = sinon.mock(new Comment({ name: 'Tony', email: 'tony@manulife.ca', subject: 'To J Snow', comments: 'I know nothing either' }));
      const comment = Mock.object;
      const expectedResult = { status: false };
      Mock.expects('save').yields(expectedResult, null);
      comment.save((err, result) => {
        Mock.verify();
        Mock.restore();
        expect(err.status).to.not.be.true;
        done();
      });
    });
  });

  // Test will pass if the comment is deleted based on an ID
  describe('Delete a comment by id', () => {
    it('should delete a comment by id', (done) => {
      const Mock = sinon.mock(Comment);
      const expectedResult = { status: true };
      Mock.expects('remove').withArgs({ _id: 12345 }).yields(null, expectedResult);
      Comment.remove({ _id: 12345 }, (err, result) => {
        Mock.verify();
        Mock.restore();
        expect(result.status).to.be.true;
        done();
      });
    });
    // Test will pass if the comment is not deleted based on an ID
    it('should return error if delete action is failed', (done) => {
      const Mock = sinon.mock(Comment);
      const expectedResult = { status: false };
      Mock.expects('remove').withArgs({ _id: 12345 }).yields(expectedResult, null);
      Comment.remove({ _id: 12345 }, (err, result) => {
        Mock.verify();
        Mock.restore();
        expect(err.status).to.not.be.true;
        done();
      });
    });
  });
});

