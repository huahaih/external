const expect = require('chai').expect;
const pageController = require('../src/controllers/pageController');

const request = {};
const response = {
  viewName: '',
  data: {},
  render(view, viewData) {
    this.viewName = view;
    this.data = viewData;
  },
};

describe('Page Controller Unit Tests:', () => {
  describe('getHome', () => {
    it('should return Home page', () => {
      pageController.getHome(request, response);
      expect(response.viewName).to.equal('pages/index');
    });
  });
  describe('getAboutPage', () => {
    it('should return About page', () => {
      pageController.getAboutPage(request, response);
      expect(response.viewName).to.equal('pages/about');
    });
  });
  describe('getAddRemoveElementsPage', () => {
    it('should return Add/Remove Elements page', () => {
      pageController.getAddRemoveElementsPage(request, response);
      expect(response.viewName).to.equal('pages/add-remove-elements');
    });
  });
  describe('getBasicAuthPage', () => {
    it('should return Basic Auth page', () => {
      pageController.getBasicAuthPage(request, response);
      expect(response.viewName).to.equal('pages/basic-auth');
    });
  });
  describe('getBrokenImagePage', () => {
    it('should return Broken Images page', () => {
      pageController.getBrokenImagePage(request, response);
      expect(response.viewName).to.equal('pages/broken-images');
    });
  });
  describe('getCheckboxesPage', () => {
    it('should return Checkboxes page', () => {
      pageController.getCheckboxesPage(request, response);
      expect(response.viewName).to.equal('pages/checkboxes');
    });
  });
  describe('getContextMenuPage', () => {
    it('should return Context Menu page', () => {
      pageController.getContextMenuPage(request, response);
      expect(response.viewName).to.equal('pages/context-menu');
    });
  });
  describe('getLargePage', () => {
    it('should return Large & Deep DOM page', () => {
      pageController.getLargePage(request, response);
      expect(response.viewName).to.equal('pages/large');
    });
  });
  describe('getDragAndDropPage', () => {
    it('should return Drag and Drop page', () => {
      pageController.getDragAndDropPage(request, response);
      expect(response.viewName).to.equal('pages/drag-and-drop');
    });
  });
  describe('getDropdownPage', () => {
    it('should return Dropdown page', () => {
      pageController.getDropdownPage(request, response);
      expect(response.viewName).to.equal('pages/dropdown');
    });
  });
  describe('getDynamicLoadingPage', () => {
    it('should return Dynamic Loading page', () => {
      pageController.getDynamicLoadingPage(request, response);
      expect(response.viewName).to.equal('pages/dynamic-loading');
    });
  });
  describe('getDynamicLoadingPage1', () => {
    it('should return Dynamic Loading1 page', () => {
      pageController.getDynamicLoadingPage1(request, response);
      expect(response.viewName).to.equal('pages/dynamic-loading-1');
    });
  });
  describe('getDynamicLoadingPage2', () => {
    it('should return Dynamic Loading2 page', () => {
      pageController.getDynamicLoadingPage2(request, response);
      expect(response.viewName).to.equal('pages/dynamic-loading-2');
    });
  });
  describe('getFeedbackPage', () => {
    it('should return Feedback page', () => {
      pageController.getFeedbackPage(request, response);
      expect(response.viewName).to.equal('pages/feedback');
    });
  });
  describe('sendFeedback', () => {
    it('should return Send Feedback page', () => {
      pageController.getSendFeedbackPage(request, response);
      expect(response.viewName).to.equal('pages/sendFeedback');
    });
  });
  describe('getFileDownloadPage', () => {
    it('should return File Download page', () => {
      pageController.getFileDownloadPage(request, response);
      expect(response.viewName).to.equal('pages/file-download');
    });
  });
  describe('getInputsPage', () => {
    it('should return Inputs page', () => {
      pageController.getInputsPage(request, response);
      expect(response.viewName).to.equal('pages/inputs');
    });
  });
  describe('getJavaScriptAlertsPage', () => {
    it('should return JavaScript Alerts page', () => {
      pageController.getJavaScriptAlertsPage(request, response);
      expect(response.viewName).to.equal('pages/javascript-alerts');
    });
  });
  describe('getKeyPressesPage', () => {
    it('should return Key Presses page', () => {
      pageController.getKeyPressesPage(request, response);
      expect(response.viewName).to.equal('pages/key-presses');
    });
  });
  describe('getMultiLanguageEnPage', () => {
    it('should return Multi Language Test: English page', () => {
      pageController.getMultiLanguageEnPage(request, response);
      expect(response.viewName).to.equal('pages/multi-language-en');
    });
  });
  describe('getMultiLanguageFrPage', () => {
    it('should return Multi Language Test: French page', () => {
      pageController.getMultiLanguageFrPage(request, response);
      expect(response.viewName).to.equal('pages/multi-language-fr');
    });
  });
  describe('getEmailPage', () => {
    it('should return Email page', () => {
      pageController.getEmailPage(request, response);
      expect(response.viewName).to.equal('pages/email');
    });
  });
});
