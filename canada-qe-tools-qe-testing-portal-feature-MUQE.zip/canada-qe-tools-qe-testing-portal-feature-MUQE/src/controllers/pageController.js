const path = require('path');
const fs = require('fs');

exports.getHome = (req, res) => {
  res.render('pages/index');
};

exports.getAboutPage = (req, res) => {
  res.render('pages/about');
};

exports.getAddRemoveElementsPage = (req, res) => {
  res.render('pages/add-remove-elements');
};

exports.getBasicAuthPage = (req, res) => {
  res.render('pages/basic-auth');
};

exports.getBrokenImagePage = (req, res) => {
  res.render('pages/broken-images');
};

exports.getCheckboxesPage = (req, res) => {
  res.render('pages/checkboxes');
};

exports.getContextMenuPage = (req, res) => {
  res.render('pages/context-menu');
};

exports.getLargePage = (req, res) => {
  res.render('pages/large');
};

exports.getDragAndDropPage = (req, res) => {
  res.render('pages/drag-and-drop');
};

exports.getDropdownPage = (req, res) => {
  res.render('pages/dropdown');
};

exports.getDynamicLoadingPage = (req, res) => {
  res.render('pages/dynamic-loading');
};

exports.getDynamicLoadingPage1 = (req, res) => {
  res.render('pages/dynamic-loading-1');
};

exports.getDynamicLoadingPage2 = (req, res) => {
  res.render('pages/dynamic-loading-2');
};

exports.getFeedbackPage = (req, res) => {
  res.render('pages/feedback');
};

exports.getSendFeedbackPage = (req, res) => {
  res.render('pages/sendFeedback');
};

exports.getFileDownloadPage = (req, res) => {
  res.render('pages/file-download');
};

exports.downloadFile = (req, res) => {
  const file = path.join(__dirname, '../public/files', req.params.filename);
  res.download(file);
};

exports.getFileUploadPage = (req, res) => {
  res.render('pages/file-upload');
};

exports.getFileUploadResultPage = (req, res) => {
  const uploadfilesFolder = path.join(__dirname, '../public/uploadfiles');
  let uploadfiles = [];
  fs.readdirSync(uploadfilesFolder).forEach(file => {
    uploadfiles.push(file)
  });
  res.render('pages/file-upload-result', { title: 'File List', filesList: uploadfiles });
};

exports.uploadFile = (req, res) => {
  let tempFile;
  let uploadPath;

  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send("<script>alert('No files were uploaded.'); window.location.href = '/file-upload'; </script>");
  }

  tempFile = req.files.sampleFile;
  uploadPath = path.join(__dirname, '../public/uploadfiles', tempFile.name);

  // Use the mv() method to place the file somewhere on your server
  tempFile.mv(uploadPath, function (err) {
    if (err) {
      return res.status(500).send(err);
    }
    res.redirect('/file-upload-result');
  });
};

exports.deleteFile = (req, res) => {
  let filePath = path.join(__dirname, '../public/uploadfiles', req.params.filename);
  fs.unlinkSync(filePath);
  res.redirect('/file-upload-result');
}

exports.downloadUploadFile = (req, res) => {
  const file = path.join(__dirname, '../public/uploadfiles', req.params.filename);
  res.download(file);
};

exports.getInputsPage = (req, res) => {
  res.render('pages/inputs');
};

exports.getJavaScriptAlertsPage = (req, res) => {
  res.render('pages/javascript-alerts');
};

exports.getKeyPressesPage = (req, res) => {
  res.render('pages/key-presses');
};

exports.getMultiLanguageEnPage = (req, res) => {
  res.render('pages/multi-language-en');
};

exports.getMultiLanguageFrPage = (req, res) => {
  res.render('pages/multi-language-fr');
};

exports.getEmailPage = (req, res) => {
  res.render('pages/email');
};

exports.getAodaPage = (req, res) => {
  res.render('pages/aoda');
};

exports.sendEmail = (req, res) => {
  const nodemailer = require('nodemailer');
  const transporter = nodemailer.createTransport({
    host: 'smtp-mail.outlook.com', // hostname
    secureConnection: false, // TLS requires secureConnection to be false
    port: 587, // port for secure SMTP
    tls: {
      ciphers: 'SSLv3',
    },
    auth: {
      user: req.body.user,
      pass: req.body.password,
    },
  });

  const mailOptions = {
    from: req.body.user,
    to: req.body.email,
    subject: req.body.subject,
    text: req.body.message,
    // html: '<b>Hello world</b><br>This is an email sent with Nodemailer in Node.js'
  };

  if (req.body.attach) {
    mailOptions.attachments = [{
      filename: 'pdf-sample.pdf',
      path: path.join(__dirname, '../public/files/pdf-sample.pdf'),
      contentType: 'application/pdf',
    }];
  }

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
      return error;
    }
    console.log(`Message sent: ${info.response}`);
    return info.response;
  });

  res.render('pages/sendEmail');
};
