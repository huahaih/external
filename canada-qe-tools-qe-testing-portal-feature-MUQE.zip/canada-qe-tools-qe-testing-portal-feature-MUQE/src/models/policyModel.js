const mongoose = require('mongoose');
const { Schema } = mongoose;
const policyModel = new Schema(
  {
    resourceType: {
      type: String,
    },
    id: {
      type: String,
    },
    text: {
      status: {
        type: String,
      },
    },
    identifier: {
      system: {
        type: String,
      },
      value: {
        type: String,
      },
    },
    applies: {
      start: {
        type: Date,
      },
    },
    type: {
      coding: {
        type: [
          Schema.Types.Mixed,
        ],
      },
    },
    term: {
      type: [
        Schema.Types.Mixed,
      ],
    },
  },
  {
    collection: 'policy',
  },
);

module.exports = mongoose.model('Policy', policyModel);
