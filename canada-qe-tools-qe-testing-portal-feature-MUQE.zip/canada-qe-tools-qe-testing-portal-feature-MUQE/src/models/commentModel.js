const mongoose = require('mongoose');
const { Schema } = mongoose;
const commentModel = new Schema(
  {
    name: { type: String },
    email: { type: String },
    subject: { type: String },
    comments: { type: String },
  },
  {
    collection: 'comments',
  },
);

module.exports = mongoose.model('Comment', commentModel);
