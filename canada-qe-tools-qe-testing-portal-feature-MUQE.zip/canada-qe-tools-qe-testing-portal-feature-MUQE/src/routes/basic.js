const pageController = require('../controllers/pageController');
const basicAuth = require('express-basic-auth');

module.exports = (app, db) => {
  app.route('/')
    .get(pageController.getHome);
  app.route('/about')
    .get(pageController.getAboutPage);
  app.route('/add-remove-elements/')
    .get(pageController.getAddRemoveElementsPage);
  app.route('/basic-auth')
    .get(basicAuth({
      challenge: true,
      users: { admin: 'admin' },
    }), pageController.getBasicAuthPage);
  app.route('/broken-images')
    .get(pageController.getBrokenImagePage);
  app.route('/checkboxes')
    .get(pageController.getCheckboxesPage);
  app.route('/context-menu')
    .get(pageController.getContextMenuPage);
  app.route('/large')
    .get(pageController.getLargePage);
  app.route('/drag-and-drop')
    .get(pageController.getDragAndDropPage);
  app.route('/dropdown')
    .get(pageController.getDropdownPage);
  app.route('/dynamic-loading')
    .get(pageController.getDynamicLoadingPage);
  app.route('/dynamic-loading/1')
    .get(pageController.getDynamicLoadingPage1);
  app.route('/dynamic-loading/2')
    .get(pageController.getDynamicLoadingPage2);
  app.route('/feedback')
    .get(pageController.getFeedbackPage);
  app.route('/sendFeedback')
    .post(pageController.getSendFeedbackPage);
  app.route('/file-download')
    .get(pageController.getFileDownloadPage);
  app.route('/file-upload')
    .get(pageController.getFileUploadPage);
  app.route('/file-download/:filename')
    .get(pageController.downloadFile);
  app.route('/file-download-uploadfiles/:filename')
    .get(pageController.downloadUploadFile);
  app.route('/upload')
    .post(pageController.uploadFile);
  app.route('/file-upload-result')
    .get(pageController.getFileUploadResultPage);
  app.route('/file-upload-result/:filename')
    .get(pageController.deleteFile);
  app.route('/key-presses')
    .get(pageController.getKeyPressesPage);
  app.route('/inputs')
    .get(pageController.getInputsPage);
  app.route('/javascript-alerts')
    .get(pageController.getJavaScriptAlertsPage);
  app.route('/multi-language-en')
    .get(pageController.getMultiLanguageEnPage);
  app.route('/multi-language-fr')
    .get(pageController.getMultiLanguageFrPage);
  app.route('/email')
    .get(pageController.getEmailPage);
  app.route('/sendEmail')
    .post(pageController.sendEmail);
  app.route('/aoda')
    .get(pageController.getAodaPage);
};
