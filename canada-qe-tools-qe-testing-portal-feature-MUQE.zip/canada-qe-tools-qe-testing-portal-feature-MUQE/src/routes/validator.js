export const isInvalidId = (id) => Number.isNaN(parseInt(id, 10));
