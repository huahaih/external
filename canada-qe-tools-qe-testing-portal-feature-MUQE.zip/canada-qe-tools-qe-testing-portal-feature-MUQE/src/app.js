const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');
const cors = require('cors');
const dataRoutes = require('./routes/basic');
const app = express();
const fileUpload = require('express-fileupload');

app.use(express.json()).use(cors());
app.use(bodyParser.urlencoded({ extended: false }));

// enable files upload
app.use(fileUpload({
  limits: { fileSize: 1 * 1024 * 1024 }
}));

dataRoutes(app);

const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('../swagger.json');

app.use('/api/v1/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, '/public')));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({ secret: 'ssshhhhh', saveUninitialized: true, resave: true }));

module.exports = app;

// // Send JSON object as a response
// app.get('/comments', (req, res) => res.send(models.comments));

app.get('/login', (req, res) => {
  const sessionData = req.session;

  if (sessionData.error) {
    res.locals.classType = 'error';
    res.locals.notice = sessionData.error;
  } else if (sessionData.success) {
    res.locals.classType = 'success';
    res.locals.notice = sessionData.success;
  } else {
    res.locals.classType = '';
    res.locals.notice = '';
  }
  sessionData.destroy();
  res.render('pages/login');
});

app.get('/secure', (req, res) => {
  const sessionData = req.session;

  if (req.session.login && req.session.login === true) {
    // To show messages in secure page
    res.locals.classType = 'success';
    res.locals.notice = req.session.notice;
    res.render('pages/secure');
    sessionData.destroy();
  } else {
    // To pass data using session
    sessionData.error = 'You must login to view the secure area!';
    res.redirect('/login');
  }
});

app.get('/logout', (req, res) => {
  const sessionData = req.session;

  sessionData.success = 'You logged out of the secure area!';
  res.redirect('/login');
});

app.post('/authenticate', (req, res) => {
  const usernameString = 'tomsmith';
  const passwordString = 'SuperSecretPassword!';
  const sessionData = req.session;

  if (req.body.username === usernameString) {
    if (req.body.password === passwordString) {
      sessionData.login = true;
      sessionData.notice = 'You logged into a secure area!';
      sessionData.classType = 'success';
      res.redirect('/secure');
    } else {
      sessionData.error = 'Your password is invalid!';
      res.redirect('/login');
    }
  } else {
    sessionData.error = 'Your username is invalid!';
    res.redirect('/login');
  }
});

